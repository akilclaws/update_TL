import rclpy
from rclpy.node import Node
import numpy as np
import simpleaudio as sa
from std_msgs.msg import Float32MultiArray

class AudioSubscriber(Node):
    def __init__(self):
        super().__init__('audio_subscriber')

        self.subscription = self.create_subscription(
            Float32MultiArray,
            'audio_data',
            self.audio_callback,
            10
        )
        self.get_logger().info("Audio Subscriber started...")

    def audio_callback(self, msg):
        np_data = np.array(msg.data, dtype=np.int16)  # Convert back to int16
        play_obj = sa.play_buffer(np_data, 1, 2, 44100)
        play_obj.wait_done()

def main(args=None):
    rclpy.init(args=args)
    node = AudioSubscriber()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("Shutting down Audio Subscriber")
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()

