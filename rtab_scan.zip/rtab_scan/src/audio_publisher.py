import rclpy
from rclpy.node import Node
import pyaudio
import numpy as np
from std_msgs.msg import Float32MultiArray

class AudioPublisher(Node):
    def __init__(self):
        super().__init__('audio_publisher')

        # Define recording parameters
        self.FORMAT = pyaudio.paInt16
        self.CHANNELS = 1
        self.RATE = 44100  # Sample rate
        self.CHUNK = 512  # Buffer size

        # Initialize PyAudio
        self.audio = pyaudio.PyAudio()

        # Find device index for "OSM09"
        device_index = None
        for i in range(self.audio.get_device_count()):
            dev_info = self.audio.get_device_info_by_index(i)
            if "OSM09" in dev_info["name"]:  # Match device name
                device_index = i
                break

        if device_index is None:
            self.get_logger().warn("OSM09 device not found. Using default input device.")
            device_index = self.audio.get_default_input_device_info()["index"]

        self.get_logger().info(f"Using device index: {device_index}")

        # Open audio stream
        self.stream = self.audio.open(
            format=self.FORMAT,
            channels=self.CHANNELS,
            rate=self.RATE,
            input=True,
            frames_per_buffer=self.CHUNK,
            input_device_index=device_index
        )

        # ROS 2 Publisher
        self.publisher_ = self.create_publisher(Float32MultiArray, 'audio_data', 10)

        # Create a timer to continuously publish audio
        self.timer = self.create_timer(0.01, self.publish_audio)

    def publish_audio(self):
        data = self.stream.read(self.CHUNK, exception_on_overflow=False)
        np_data = np.frombuffer(data, dtype=np.int16)  # Convert to NumPy array
        msg = Float32MultiArray()
        msg.data = np_data.astype(np.float32).tolist()  # Convert to float for compatibility
        self.publisher_.publish(msg)
        self.get_logger().info("Publishing audio data...")

    def destroy_node(self):
        self.stream.stop_stream()
        self.stream.close()
        self.audio.terminate()
        super().destroy_node()

def main(args=None):
    rclpy.init(args=args)
    node = AudioPublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("Shutting down Audio Publisher")
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()

