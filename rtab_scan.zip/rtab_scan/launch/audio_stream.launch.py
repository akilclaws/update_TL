import os
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='rtab_scan',  # Replace with your actual package name
            executable='audio_publisher',  # Name of the publisher node executable
            name='audio_publisher',
            output='screen'
        ),
        Node(
            package='rtab_scan',  # Replace with your actual package name
            executable='audio_subscriber',  # Name of the subscriber node executable
            name='audio_subscriber',
            output='screen'
        )
    ])

