import launch
import launch_ros.actions
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare

def generate_launch_description():
    # TurtleBot3 Bringup
    turtlebot3_bringup = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution([
                FindPackageShare("turtlebot3_bringup"), "launch", "robot.launch.py"
            ])
        )
    )

    # Odrive launch file
    odrive_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution([
                FindPackageShare("rtab_scan"), "launch", "odrive_diffbot.launch.py"
            ])
        )
    )

    # RPLidar launch file
    rplidar_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution([
                FindPackageShare("rtab_scan"), "launch", "rplidar_a3_launch.py"
            ])
        )
    )

    # RTAB-Map launch file
    rtabmap_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution([
                FindPackageShare("rtab_scan"), "launch", "turtlebot3_scan.launch.py"
            ])
        )
    )

    # Navigation launch file
    navigation_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution([
                FindPackageShare("rtab_scan"), "launch", "navigation_launch.py"
            ])
        )
    )

    # RViz launch file
    rviz_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution([
                FindPackageShare("rtab_scan"), "launch", "rviz_launch.py"
            ])
        )
    )

    return LaunchDescription([
        #turtlebot3_bringup,
        #odrive_launch,
        # rtabmap_launch,
        #rplidar_launch,
        #navigation_launch,
        rviz_launch
    ])